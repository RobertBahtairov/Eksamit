# Pyman

Pacman copy implemented in Python (with bad sound effects and music).

To run game, must have `Python3` and `Pygame` installed.

Python script to run is "game.py", located under ./files/

![alt text](images/pygame-gameplay.png "Logo Title Text 1")
