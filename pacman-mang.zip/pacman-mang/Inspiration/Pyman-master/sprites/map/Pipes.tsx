<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="Pipes" tilewidth="16" tileheight="16" tilecount="10" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="16" height="16" source="pipes-1.png"/>
 </tile>
 <tile id="1">
  <image width="16" height="16" source="pipes-2.png"/>
 </tile>
 <tile id="2">
  <image width="16" height="16" source="pipes-3.png"/>
 </tile>
 <tile id="3">
  <image width="16" height="16" source="pipes-4.png"/>
 </tile>
 <tile id="4">
  <image width="16" height="16" source="pipes-5.png"/>
 </tile>
 <tile id="5">
  <image width="16" height="16" source="pipes-6.png"/>
 </tile>
 <tile id="7">
  <image width="16" height="16" source="pipes-8.png"/>
 </tile>
 <tile id="8">
  <image width="16" height="16" source="pipes-7.png"/>
 </tile>
 <tile id="9">
  <image width="16" height="16" source="pipes-9.png"/>
 </tile>
 <tile id="10">
  <image width="16" height="16" source="pipes-10.png"/>
 </tile>
</tileset>
