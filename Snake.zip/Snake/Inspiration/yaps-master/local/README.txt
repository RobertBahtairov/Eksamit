This folder contains highscores and preferences.
